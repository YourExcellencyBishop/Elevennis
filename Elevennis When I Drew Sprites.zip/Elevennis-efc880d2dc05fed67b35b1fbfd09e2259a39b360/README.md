# GameMaker Devvit Template

A template for integrating GameMaker WASM games into Reddit's Devvit platform.
This is intended as a GameMaker wasm equivalent to the Devvit templates and is based on the Devvit "Hello World" Template: https://github.com/reddit/devvit-template-hello-world

## Get Started

For instructions on how to get setup as a Reddit developer and start deploying GameMaker games to reddit, see [How To Build](docs/HowToBuild.md)